/*
 * Rajat Kuthiala
 * LAB-4
 * Part:6
 * CSC-172
 * TA: Shuyang Liu
 * Partner: Jordy
 * 
 * I affirm that I have not given 
 * or received any unauthorized help 
 * on this assignment, and that this 
 * work is my own.
 */

For this lab, I created a linked list using an interface setup a class for the nodes, a class to implement the linked list and a main class to test the functions.
