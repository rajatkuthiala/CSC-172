/*
 * Rajat Kuthiala
 * LAB-4
 * CSC-172
 * TA: Shuyang Liu
 * Partner: Jordy
 * 
 * I affirm that I have not given 
 * or received any unauthorized help 
 * on this assignment, and that this 
 * work is my own.
 */

// Section 1 of Lab. Implementation of a Node
public class MyNode<AnyType> {
	
	public AnyType data;
	public MyNode<AnyType> next;
}
