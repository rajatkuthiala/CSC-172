/*
 * Rajat Kuthiala
 * Project 2
 * CSC-172
 * TA: Shuyang Liu
 * 
 */

For this project we had to build a postfix calculator that read in infix expressions from a text document, converted them, then printed the output to another file. I did this 
by following the Shunting-Yard method as described on the wikipedia page, as well as on the lab assignment. The post fix calculator was then implemented based off the instructions 
in the lab assignment. I 

There are few bugs in the program and in few cases, I was not getting the output i was expecting through wolfram.


References:
Google
Wikipedia
Stackoverflow( i/o operations and a little bit about stacks)

Discussions with my lab partner Jordy and Robert.