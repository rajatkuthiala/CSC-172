/*
 * Rajat Kuthiala
 * LAB-5
 * CSC-172
 * TA: Shuyang Liu
 * Partner: Jordy
 * 
 * I affirm that I have not given 
 * or received any unauthorized help 
 * on this assignment, and that this 
 * work is my own.
 */


For this lab, I created a doubly linked list using an interface setup, a class for the double nodes, a class to implement the double linked list and a main class to test the functions.