/*
 * Rajat Kuthiala
 * LAB-1
 * Part:6
 * CSC-172
 * TA: Shuyang Liu
 * Partner: Jordy
 * 
 * I affirm that I have not given 
 * or received any unauthorized help 
 * on this assignment, and that this 
 * work is my own.
 */


This lab is based on usage of generics.
Sections 1-5 of the lab covered method overloading 
and generic type safety while section 6 introduced 
function objects.

The code is split in 2 parts. 
Part Lab.Java contans section 1-5.
Part Part6.Java contains section 6.
An output file has been included in the zip.
