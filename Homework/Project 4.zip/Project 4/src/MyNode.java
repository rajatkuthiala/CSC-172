/*
 * Rajat Kuthiala
 * Project 4
 * CSC-172
 * TA: Shuyang Liu
 * 
 */


public class MyNode<AnyType> {
  public AnyType data; //stores the item for the list
  public MyNode<AnyType> next; //points to the next item in the list
}
