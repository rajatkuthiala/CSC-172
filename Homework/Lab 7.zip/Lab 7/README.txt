/*
 * Rajat Kuthiala
 * LAB-7
 * CSC-172
 * TA: Shuyang Liu
 * Partner: Jordy
 * 
 * I affirm that I have not given 
 * or received any unauthorized help 
 * on this assignment, and that this 
 * work is my own.
 */

README:

The basic code used is from last lab with addition of method like checkFirst and removeFirst.

