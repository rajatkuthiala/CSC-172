/*
 * Rajat Kuthiala
 * LAB-16
 * CSC-172
 * TA: Shuyang Liu
 * Partner: Jordy
 * 
 * I affirm that I have not given 
 * or received any unauthorized help 
 * on this assignment, and that this 
 * work is my own.
 */
The code for Bubble Sort, Insertion Sort and Shell Sort came from the lab. The main idea of this lab was to implement these sorting algorithms as well as the built-in Array Sort and plot their respective runtimes. The graphs for each sorting algorithm was roughly equal to the actual big-oh. The graphs matched up with the theories with slight deviations. Sorting Graphs.pdf contains the charts I created using excel with time as the y-axis and size as the x-axis. The increments I used depended on the sorting algorithm. 