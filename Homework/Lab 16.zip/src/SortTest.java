/*
 * Rajat Kuthiala
 * LAB-16
 * CSC-172
 * TA: Shuyang Liu
 * Partner: Jordy
 * 
 * I affirm that I have not given 
 * or received any unauthorized help 
 * on this assignment, and that this 
 * work is my own.
 */

import java.util.Arrays;

public class SortTest {

    private static int count;

    public static void main(String args[]) {

        long startTime, endTime, elapsedTime;
        int size = Integer.parseInt(args[0]);

        Integer[] a = new Integer[size];
        Integer[] b = new Integer[size];

        for (int i = 0; i < size; i++) {
            a[i] = b[i] = (int) (Math.random() * 100);
        }

        // Bubble Sort
        count = 0;
        startTime = System.currentTimeMillis();
        bubblesort(a);
        endTime = System.currentTimeMillis();
        elapsedTime = endTime - startTime;

        System.out.println("bubblesort took " + count + " moves to sort " + size + " items");
        System.out.println("\t in : " + elapsedTime + " millesec");

        // Reset count and array
        count = 0;
        for (int i = 0; i < size; i++) {
            a[i] = b[i];
        }

        // Insertion Sort
        count = 0;
        startTime = System.currentTimeMillis();
        insertionSort(a);
        endTime = System.currentTimeMillis();
        elapsedTime = endTime - startTime;

        System.out.println("insertionsort took " + count + " moves to sort " + size + " items");
        System.out.println("\t in : " + elapsedTime + " millesec");

        // Reset count and array
        count = 0;
        for (int i = 0; i < size; i++) {
            a[i] = b[i];
        }

        // Shell Sort
        count = 0;
        startTime = System.currentTimeMillis();
        shellsort(a);
        endTime = System.currentTimeMillis();
        elapsedTime = endTime - startTime;

        System.out.println("shellsort took " + count + " moves to sort " + size + " items");
        System.out.println("\t in : " + elapsedTime + " millesec");

        // Reset Count and array
        count = 0;
        for (int i = 0; i < size; i++) {
            a[i] = b[i];
        }

        // Library Sort
        count = 0;
        startTime = System.currentTimeMillis();
        Arrays.sort(a);
        endTime = System.currentTimeMillis();
        elapsedTime = endTime - startTime;
        System.out.println("Sort took " + size + " items");
        System.out.println("\t in : " + elapsedTime + " millesec");

    }

    // Bubble Sort: Runtime of O(n^2)
    public static <AnyType extends Comparable<? super AnyType>> void bubblesort(AnyType[] a) {
        for (int i = 0; i < a.length; i++) {
            for (int j = 0; j < a.length - 1; j++) {
                if (a[j].compareTo(a[j + 1]) > 0) {
                    AnyType tmp = a[j];
                    count++;
                    a[j] = a[j + 1];
                    count++;
                    a[j + 1] = tmp;
                    count++;
                }
            }
        }
    }

    // Insertion Sort: Runtime of O(n^2)
    public static <AnyType extends Comparable<? super AnyType>> void insertionSort(AnyType[] a) { //big O(n^2)
        for (int i = 1; i < a.length; i++) {
            int j = i;
            while (j > 0 && (a[j - 1].compareTo(a[j]) > 0)) {
                AnyType temp = a[j];
                a[j] = a[j - 1];
                count++;
                a[j - 1] = temp;
                count++;
                j--;
            }
        }
    }

    // Shell Sort: Runtime of O(n^3/2)
    public static <AnyType extends Comparable<? super AnyType>> void shellsort(AnyType[] a) {
        int j;
        for (int gap = a.length / 2; gap > 0; gap /= 2)
            for (int i = gap; i < a.length; i++) {
                AnyType tmp = a[i];
                for (j = i; j >= gap && tmp.compareTo(a[j - gap]) < 0; j -= gap) {
                    a[j] = a[j - gap];
                    count++;
                }
                a[j] = tmp;
                count++;
            }
    }


}