/*
 * Rajat Kuthiala
 * LAB-11
 * CSC-172
 * TA: Shuyang Liu
 * Partner: Jordy
 * 
 * I affirm that I have not given 
 * or received any unauthorized help 
 * on this assignment, and that this 
 * work is my own.
 */

README:

Good introduction to Scheme. I wasn’t sure whether to include the code that he put on the lab so I did not because that would just be copying and pasting. To create the GCD function in Scheme, I used a java version first than tried to convert that to the Scheme language. I had trouble with usage of if but using cond worked better.